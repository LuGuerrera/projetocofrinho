package empresa;

import java.util.ArrayList;
import java.util.List;

class Cofrinho {
	
    private List<Moeda> moedas;

    public Cofrinho() {
    	
        this.moedas = new ArrayList<>();
    }
    
// coloca moeda no cofrinho
    public void adicionarMoeda(Moeda moeda) {
    	
        moedas.add(moeda);
    }
    
//remove moeda do cofrinho
    public void removerMoeda(Moeda moeda) {
    	
        moedas.remove(moeda);
    }

    public void listarMoedas() {
    	
        for (Moeda moeda : moedas) {
        	
            System.out.println(moeda.getNome() + " - " + moeda.getValor());
        }
    }

    
 // calcula o total de dinheiro no cofrinho convertido para reais
    public double calcularTotalEmReais() {
    	
        double total = 0;
        for (Moeda moeda : moedas) {
        	
            total += moeda.converterParaReal();
        }
        
        return total;
    }

    public List<Moeda> getMoedas() {
    	
        return moedas;
    }
}

