package empresa;

class Dolar extends Moeda {
	
	//construtor para iniciar valor do dolar
    public Dolar(double valor) {
    	
        super(valor);
    }

 // Converte o valor dolar para reais com a conversão inventada
    public double converterParaReal() {
    	
        return valor * 4.27; 
    }

    @Override
    public String getNome() {
    	
        return "Dolar";
    }
}