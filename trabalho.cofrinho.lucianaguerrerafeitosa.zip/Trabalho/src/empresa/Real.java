package empresa;

class Real extends Moeda {
	
	//construtor para iniciar valor do real
    public Real(double valor) {
    	
        super(valor);
    }

    @Override
    public double converterParaReal() {
    	
        return valor;
    }

    @Override
    public String getNome() {
    	
        return "Real";
    }
}