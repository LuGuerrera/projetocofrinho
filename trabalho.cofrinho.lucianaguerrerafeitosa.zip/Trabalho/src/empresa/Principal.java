
package empresa;

import java.util.Scanner;

public class Principal {
	
    public static void main(String[] args) {
    	
        Scanner scanner = new Scanner(System.in);
        
        
        Cofrinho cofrinho = new Cofrinho();
        int opcao;

        do {
            System.out.println("1. Adicionar moeda");
            System.out.println("2. Remover moeda");
            System.out.println("3. Listagem de moedas");
            System.out.println("4. Calculo total de moedas em reais");
            System.out.println("5. Encerrar..");
            
            opcao = scanner.nextInt();
            switch (opcao) {
            
                case 1:
                	 // adiciona moeda no cofrinho
                    System.out.println("Escolha entre as opções de moedas: 1. Real 2. Dolar 3. Euro");
                    int tipoMoeda = scanner.nextInt();
                    
                    System.out.println("Digite o valor desejado:");
                    double valor = scanner.nextDouble();
                    Moeda moeda = null;
                    switch (tipoMoeda) {
                    
                        case 1:
                            moeda = new Real(valor);
                            break;
                        case 2:
                            moeda = new Dolar(valor);
                            break;
                        case 3:
                            moeda = new Euro(valor);
                            break;
                    }
                    
                    if (moeda != null) {
                        cofrinho.adicionarMoeda(moeda);
                    }
                    break;

                    
                case 2:
                	// eemove moeda do cofrinho
                    System.out.println("informe o valor da moeda que deseja remover:");
                    valor = scanner.nextDouble();
                    Moeda moedaARemover = null;
                    
                    
                    for (Moeda m : cofrinho.getMoedas()) {
                    	
                        if (m.getValor() == valor) {
                            moedaARemover = m;
                            break;
                        }
                    }
                    
                    
                    if (moedaARemover != null) {
                        cofrinho.removerMoeda(moedaARemover);
                        System.out.println(" moeda removida.");
                        
                    } else {
                        System.out.println(" A moeda informada não foi encontrada..");
                    }
                    break;
                                        

                case 3:
                    cofrinho.listarMoedas();
                    break;

                case 4:
                	// calcula e mostra o total em Reais
                    System.out.println("Total em Reais: " + cofrinho.calcularTotalEmReais());
                    break;

                case 5:
                    System.out.println("encerrando....");
                    break;

                default:
                    System.out.println("opcao invalida!");
                    break;
            }
            
        } while (opcao != 5);

        
        scanner.close();
    }
}
