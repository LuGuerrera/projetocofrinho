package empresa;

class Euro extends Moeda {
	
	//construtor para iniciar valor do euro
    public Euro(double valor) {
        super(valor);
    }

    
    // Converte o valor euro para reais com a conversão inventada
    @Override
    public double converterParaReal() {
        return valor * 3.18; 
    }

    @Override
    public String getNome() {
    	
        return "Euro";
    }
}